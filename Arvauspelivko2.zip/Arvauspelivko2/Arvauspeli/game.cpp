#include <iostream>
#include "game.h"
#include <cstdlib>
using namespace std;

game::game(int max) // tuodaan main-funktiossa pelille maksimiarvo
{
maxNumber = max; // tallennetaan se globaaliin muuttujaan
    cout << "Konstruktorille annettu arvo " << max << endl << endl;
}

void game::play()
{

    randomNumber = rand() % (maxNumber +1); // lisätään 1, koska rand % maxnumber asettaa ylärajaksi annetusta numerosta seuraavaksi pienimmän
    playerGuess = 0;
    numOfGuesses = 0;
    cout << "Maksimiarvo on: " << maxNumber << "." << endl;
    do // do-while-loopilla on helppo toteuttaa looppi oikein, vaikka arvaus menisikin ykkösellä oikein
    {
        numOfGuesses++; // lisätään heti arvausten määrään 1
        cout << "Arvaa numero 0:n ja " << maxNumber << ":n valista: ";

        cin >> playerGuess;
        cout << "Arvausten maaara: " << numOfGuesses << endl;
        if(playerGuess > randomNumber)
        {
            cout << "Liian suuri \n" << endl;
        }
        if(playerGuess < randomNumber)
        {
            cout << "Liian pieni \n" << endl;
        }
        if(playerGuess == randomNumber)
        {
            cout << "Oikein! \n" << endl;
        }
    }while(randomNumber != playerGuess);

printGameResults();
}

void game::printGameResults()
{
    cout << "Arvasit oikein " << numOfGuesses << ":lla arvauksella";

}

game::~game(){}


int maks() // maksimiarvon määritykselle oma funktio tilan säästämiseksi main-funktiossa
{
    int maks1;
    cout << "Anna maksimiarvo: ";
    cin >> maks1;
    return maks1;
}
