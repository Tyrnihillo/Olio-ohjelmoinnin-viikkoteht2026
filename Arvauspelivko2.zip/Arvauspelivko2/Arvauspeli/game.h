#ifndef ARVAUSPELI_H
#define ARVAUSPELI_H

class game
{
public:
    game(int);
    ~game();
    void play();

private:
    int maxNumber;
    int playerGuess;
    int randomNumber;
    int numOfGuesses;

    void printGameResults();
};




#endif // ARVAUSPELI_H
