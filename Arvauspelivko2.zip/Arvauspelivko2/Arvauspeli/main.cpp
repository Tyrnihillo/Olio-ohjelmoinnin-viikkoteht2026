#include <iostream>
#include "game.h"
#include <cstdlib>


using namespace std;

int maks();


int main()
{
    srand(time(0)); //randomizeriin seedin otto ajasta
    int maksimi = maks(); // maksimiarvon määrittäminen
    game x(maksimi); // konstruktori, arvon vienti ja peliolion luonti
    x.play(); // itse pelin toteuttaminen

    return 0;
}
