#include "chef.h"
#include <string>
#include <iostream>
using namespace std;

Chef::Chef(string x)
{
chefName = x;
    cout << "Kokin nimi on " << chefName;
}

Chef::~Chef()
{
}

string Chef::getName()
{
    return chefName;
}

int Chef::makeSalad(int a)
{
    cout << "Tarpeeksi aineksia " << (a/5) << ":n salaattiin." << endl;
    return (a/5);
}

int Chef::makeSoup(int b)
{
    cout << "Tarpeeksi aineksia " << (b/3) << "n soppaan." << endl;
    return (b/3);
}




