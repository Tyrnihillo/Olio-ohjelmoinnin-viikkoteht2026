#include "italianchef.h"
#include "chef.h"
#include <string>
#include <iostream>
using namespace std;

italianChef::italianChef(string s):Chef(s) // luodaan Chef(s), jolloin italianchef osaa periä s-stringin chefiltä
{
}

italianChef::~italianChef()
{
}

bool italianChef::askSecret(string pw, int a, int b)
{
    int sala = password.compare(pw);

    if(sala == 0)
    {makepizza(b, a);
     return sala;}
    else{return sala;}

}

int italianChef::makepizza(int flour, int water)
{

    int ainekset = min(water, flour) / 5;
    cout << "Tarpeeksi aineksia " << ainekset << ":n pizzaan." << endl;
    return ainekset;
}
