#include <iostream>
#include "chef.h"
#include "italianchef.h"
#include <string>
using namespace std;



int main()
{
    Chef matti("Matti");
    matti.makeSalad(12);
    italianChef risto("Teppo");
    string pw;
    cin >> pw;
    risto.askSecret(pw, 12, 13);
}
