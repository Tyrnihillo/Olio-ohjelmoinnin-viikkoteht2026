#include "luottotili.h"
#include <string>
using namespace std;


Luottotili::Luottotili(string a, double b): Pankkitili(a)
{
    luottoRaja = b;
    cout << a << ":n luottotili luotu. Luottoraja "<< b << " euroa." << endl;

}

bool Luottotili::deposit(double x)
{
    cout << omistaja << endl;
    if(saldo+x>=0){cout<< "Liian suuri maksu" << endl; return false;}
    if(x<0){cout << "Negatiivista maksua ei voida suorittaa." << endl; return false;}

    saldo+=x;
    cout<<"Talletettu " << x << " euroa. Tilin saldo: " << saldo << " euroa." << endl;
    return true;
}

bool Luottotili::withdraw(double f)
{
    cout << omistaja << endl;
    if(luottoRaja+saldo-f<=0){cout << "Liian suuri nosto" << endl; return false;}
    if(f<0){cout << "Negatiivista nostoa ei voida suorittaa." << endl; return false;}

    saldo-=f;
    cout<<"Nostettu " << f << " euroa. Tilin saldo: " << saldo << " euroa." << endl;
    return true;
}
