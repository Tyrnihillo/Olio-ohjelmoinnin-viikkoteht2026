#include <iostream>
#include "pankkitili.h"
#include <string>
#include "asiakas.h"
#include "luottotili.h"

using namespace std;

int main()
{
    Asiakas Jussi("Jussi", 500);
    Asiakas Emma("Emma", 0);

    Emma.talletus(200);
    Emma.tiliSiirto(500, Jussi);
    Jussi.luotonNosto(200);

    return 0;
}
