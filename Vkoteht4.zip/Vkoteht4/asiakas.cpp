#include "asiakas.h"

Asiakas::Asiakas(string d, double luotto): nimi(d), kayttotili(nimi), luottotili(nimi, luotto)
{
    cout<<"Asiakkuus " << nimi << " luotu." << endl;
}

string Asiakas::getNimi()
{
    return nimi;
}

void Asiakas::showSaldo()
{
    kayttotili.getBalance();
    luottotili.Pankkitili::getBalance();
}

bool Asiakas::talletus(double asd)
{
    bool onnistui = kayttotili.Pankkitili::deposit(asd);
    return onnistui;
}

bool Asiakas::nosto(double abc)
{
    bool onnistui = kayttotili.Pankkitili::withdraw(abc);
    return onnistui;
}

bool Asiakas::luotonMaksu(double xyz)
{
    bool onnistui = luottotili.deposit(xyz);
    return onnistui;
}

bool Asiakas::luotonNosto(double omg)
{
    bool onnistui = luottotili.withdraw(omg);
    return onnistui;
}

bool Asiakas::tiliSiirto(double siirto, Asiakas &d)
{

    bool onnistui = kayttotili.Pankkitili::withdraw(siirto);
    if(onnistui == true){
        d.kayttotili.Pankkitili::deposit(siirto);}

    return onnistui;
}

