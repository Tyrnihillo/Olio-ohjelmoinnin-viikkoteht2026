#include "pankkitili.h"
#include <string>
using namespace std;

Pankkitili::Pankkitili(string o) {cout << o << ":n pankkitili luotu" << endl; omistaja = o;}

double Pankkitili::getBalance()
{
    cout << omistaja << endl;
    cout << "Tilin saldo on: " << saldo << endl;
    return saldo;
}



bool Pankkitili::deposit(double x)
{
    cout << omistaja << endl;
    if(x<0){cout << "Ei voi tallettaa negatiivista arvoa" << endl; return false;}
    saldo+=x;
    cout<<"Tilille maksettu " << x << ". Tilin saldo " << saldo << endl;
    return true;
}

bool Pankkitili::withdraw(double y)
{
    cout << omistaja << endl;
    if(saldo-y < 0){cout << "Ei tarpeeksi rahaa." << endl; return false;}
    saldo-=y;
    cout<<"Tililta nostettu " << y << ". Tilin saldo " << saldo << endl;
    return true;
}
