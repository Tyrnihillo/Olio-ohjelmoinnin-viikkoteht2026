#include <iostream>
#include "seuraaja.h"
#include "notifikaattori.h"

using namespace std;

int main()
{

    Notifikaattori n;
    Seuraaja a("A");
    Seuraaja b("B");
    Seuraaja c("C");
    Seuraaja d("D");

    n.lisaa(&a);
    n.lisaa(&b);
    n.lisaa(&c);

    n.postita("Viesti");
    n.poista(&b);
    n.lisaa(&d);

    n.postita("Viesti2");
    return 0;
}
