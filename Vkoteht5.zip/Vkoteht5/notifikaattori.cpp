#include "notifikaattori.h"
#include <iostream>
#include "seuraaja.h"
using namespace std;

Notifikaattori::Notifikaattori() {}

void Notifikaattori::lisaa(Seuraaja *a) // viedään funktiolle osoitin johonkin seuraaja-luokan olioon
{
    if(a == nullptr){return;} // jos osoitin ei osoita mihinkään, return.
    a->next = seuraajat; // asetetaan next osoittamaan seuraajat-pointteria
    seuraajat = a; // tallennetaan a ketjun lenkiksi seuraajat -pointteriin
}

void Notifikaattori::poista(Seuraaja *y)
{
    if(seuraajat == nullptr || y == nullptr) {return;} // poistutaan jos ei löydy mitään

    if(seuraajat == y) // jos osuu jo ensimmäisellä
    {
        seuraajat = seuraajat->next; // siirretään ensimmäistö linkkiä yksi eteenpäin
        return;
    }

    Seuraaja *ptr = seuraajat;
    while (ptr->next != nullptr && ptr->next != y)
    // mennään eteenpäin niin kauan, että lista loppuu tai poistettava löytyy
    {
        ptr = ptr->next;
    }

    if (ptr->next == y) // jos löydetään vastaava
    {
        ptr->next = y->next; // jätetään tähän kuuluva muistipaikka välistä
        y->next = nullptr; // tyhjennetään pointteri
    }
    cout << "Seuraaja " << y->getNimi() << " Poistettu." << endl;
}

void Notifikaattori::tulosta()
{
    Seuraaja *ptr = seuraajat;
    while(ptr != nullptr)
    {
        string nimi = ptr->getNimi();
        cout << nimi << endl;

    ptr = ptr->next;
    }
}


void Notifikaattori::postita(string c)
{
    Seuraaja *ptr = seuraajat;
    while(ptr != nullptr)
    {
        ptr->paivitys(c);
        ptr = ptr->next;
    }
}
