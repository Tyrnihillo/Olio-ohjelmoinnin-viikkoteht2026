#include "seuraaja.h"

Seuraaja::Seuraaja(string x)
{
    nimi = x;
    cout << "Seuraaja " << nimi << " Luotu." << endl;
}

string Seuraaja::getNimi()
{
    return nimi;
}

void Seuraaja::paivitys(string y)
{
    cout << "Seuraaja " << nimi << " sai viestin." << y << endl;
}
