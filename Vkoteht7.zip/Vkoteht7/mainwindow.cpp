#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPushButton>


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    connect(ui->Num_0, &QPushButton::clicked, this, &MainWindow::numberClickHandler);
    connect(ui->Num_1, &QPushButton::clicked, this, &MainWindow::numberClickHandler);
    connect(ui->Num_2, &QPushButton::clicked, this, &MainWindow::numberClickHandler);
    connect(ui->Num_3, &QPushButton::clicked, this, &MainWindow::numberClickHandler);
    connect(ui->Num_4, &QPushButton::clicked, this, &MainWindow::numberClickHandler);
    connect(ui->Num_5, &QPushButton::clicked, this, &MainWindow::numberClickHandler);
    connect(ui->Num_6, &QPushButton::clicked, this, &MainWindow::numberClickHandler);
    connect(ui->Num_7, &QPushButton::clicked, this, &MainWindow::numberClickHandler);
    connect(ui->Num_8, &QPushButton::clicked, this, &MainWindow::numberClickHandler);
    connect(ui->Num_9, &QPushButton::clicked, this, &MainWindow::numberClickHandler);
    connect(ui->Add, &QPushButton::clicked, this, &MainWindow::addSubMulDivClickHandler);
    connect(ui->Sub, &QPushButton::clicked, this, &MainWindow::addSubMulDivClickHandler);
    connect(ui->Mul, &QPushButton::clicked, this, &MainWindow::addSubMulDivClickHandler);
    connect(ui->Div, &QPushButton::clicked, this, &MainWindow::addSubMulDivClickHandler);
    connect(ui->Clear, &QPushButton::clicked, this, &MainWindow::clearAndEnterClickHandler);
    connect(ui->Enter, &QPushButton::clicked, this, &MainWindow::clearAndEnterClickHandler);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::numberClickHandler()
{
    qDebug() << "Tila " << state << ".";
    QPushButton *button = qobject_cast<QPushButton*>(sender());
    if(!button)
    {return;}
    qDebug()<< " Painike " << button->text();
    if(state == 1)
    {
        QString teksti = ui->Number_1->text(); // Tallennetaan numero 1:n
        ui->Number_1->setText(teksti + button->text());

    }
    if(state == 2)
    {
        QString teksti2 = ui->Number_2->text(); // Tallennetaan numero 2:n
        ui->Number_2->setText(teksti2 + button->text());

    }
}
void MainWindow::clearAndEnterClickHandler()
{
    QPushButton *button = qobject_cast<QPushButton*>(sender());
    if(!button)
    {return;}
    qDebug()<< " Painike " << button->text();
    if (button == ui->Clear)
    {
        state = 1;
        resetLineEdits();
    }
    if (button == ui->Enter)
    {
        number1 = ui->Number_1->text();
        number2 = ui->Number_2->text();
        float numero1 = number1.toFloat();
        float numero2 = number2.toFloat(); // Tallennetaan täällä numerot näytöiltä floatiksi laskentaa varten
        switch(operand)
        {
            case 1:
            {
                result = numero1 + numero2;
                break;
            }
            case 2:
            {
                result = numero1 - numero2;
                break;
            }
            case 3:
            {
                result = numero1 * numero2;
                break;
            }
            case 4:
            {
                if(numero2 == 0)
                {
                    ui->Result->setText("Error");
                    return;
                }
                result = numero1 / numero2;
                break;
            }
        }
        state = 1;

        qDebug()<<(QString::number(result));
        ui->Result->setText(QString::number(result));
    }

}

void MainWindow::addSubMulDivClickHandler()
{
    QPushButton *button = qobject_cast<QPushButton*>(sender());
    if(!button)
    {return;}
    if (button == ui->Add){ operand = 1; }
    if (button == ui->Sub){ operand = 2; }
    if (button == ui->Mul){ operand = 3; }
    if (button == ui->Div){ operand = 4; }
    qDebug()<< " Painike " << button->text();
    state = 2;
}

void MainWindow::resetLineEdits()

{
    ui->Number_1->setText("");
    ui->Number_2->setText("");
    ui->Result->setText("");
    qDebug()<< " Reset "  << Qt::endl;
}
